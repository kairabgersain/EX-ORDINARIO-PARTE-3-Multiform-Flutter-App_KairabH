import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'App de Login',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const Login(),
        '/bienvenida': (context) => const Bienvenida(),
      },
    );
  }
}

class Bienvenida extends StatelessWidget {
  const Bienvenida({super.key});

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)!.settings.arguments as Map;
    return Scaffold(
      appBar: AppBar(
        title: const Text("Bienvenida"),
      ),
      body: Center(
        child: Text("¡Bienvenido, ${args['usuario']}!"),
      ),
    );
  }
}

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  var txtLogin = TextEditingController();
  var txtPassword = TextEditingController();
  var nombre = "";
  var clave = " ";

  void ingresar(String nombre, String clave) async {
    try {
      var url = "http://localhost/ws/validarUsuario.php";
      var uri = Uri.parse(url);
      var response = await http.post(uri, body: {
        "nombre": nombre,
        "clave": clave
      }).timeout(const Duration(seconds: 90));

      if (response.body == '1') {
        Navigator.pushNamed(context, "/bienvenida", arguments: {"usuario": nombre});
      } else {
        print("# Usuario incorrecto !");
      }
    } on TimeoutException catch (e) {
      print("Tardó mucho la conexión..");
    } on Error catch (e) {
      print("http Error de Conexión");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
            image: AssetImage("img/fondo.jpg"), fit: BoxFit.cover),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          title: const Text("Multiformularios"),
        ),
        body: ListView(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(vertical: 100, horizontal: 20),
              alignment: Alignment.center,
              child: Image.asset("img/logo.png"),
            ),
            Container(
              padding: const EdgeInsets.all(15),
              alignment: Alignment.center,
              child: TextField(
                textAlign: TextAlign.center,
                decoration: InputDecoration(
                  hintText: "Nombre de Usuario",
                ),
                controller: txtLogin,
              ),
            ),
            Container(
              padding: const EdgeInsets.all(15),
              alignment: Alignment.center,
              child: TextField(
                textAlign: TextAlign.center,
                decoration: InputDecoration(
                  hintText: "clave de usuario",
                ),
                obscureText: true,
                controller: txtPassword,
              ),
            ),
            Container(
              padding: const EdgeInsets.all(25),
              alignment: Alignment.center,
              child: ElevatedButton.icon(
                onPressed: () {
                  nombre = txtLogin.text;
                  clave = txtPassword.text;
                  if (nombre != "" && clave != "") {
                    ingresar(nombre, clave);
                  } else {
                    showDialog(
                        context: context,
                        barrierDismissible: false,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: const Text("Advertencia"),
                            content: const SingleChildScrollView(
                              child: ListBody(
                                children: [
                                  Text("Verifica tus Credenciales"),
                                ],
                              ),
                            ),
                            actions: [
                              TextButton(
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                  child: const Text("Aceptar")),
                            ],
                          );
                        });
                  }
                },
                label: const Text("Validar"),
                icon: const Icon(Icons.login),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
