import 'package:flutter/material.dart';
import 'bienvenida.dart';
import 'main.dart';
import 'perfil.dart';

void main() {
  // Este método regresa un widget MaterialApp
  runApp(
    MaterialApp(
      // Establecer las rutas de navegación del proyecto
      routes: {
        // Definimos tres rutas para navegar entre formularios
        "/login": (context) => Login(),
        "/bienvenida": (context) => Bienvenida(),
        // Esta ruta la invocamos desde un menu contextual (menu de hamburguesa)
        "/perfil": (context) => Perfil()
      },
      // Establecemos mediante la ruta cual es la primer clase que se corre de la app
      initialRoute: "/login",
    ),
  ); // runapp
}
