import 'package:flutter/material.dart';

class Perfil extends StatelessWidget {
  const Perfil({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Mi Perfil"),
      ),
      // Agregar widgets de manera vertical
      body: ListView(
        children: [
          Padding(
            padding: EdgeInsets.all(20),
            child: Text("Mi Perfil Personal"),
          ),
        ],
      ),
    );
  }
}
