import 'package:flutter/material.dart';

class Bienvenida extends StatefulWidget {
  // constructo por defecto const Bienvenida({super.key});

  // Recibimos datos del usuario del primer activity
  //final String name;
  // Constructo de la clase
  //const Bienvenida(this.name, {super.key});

  Bienvenida();
  @override
  State<Bienvenida> createState() => _BienvenidaState();
}

// Construye la App

class _BienvenidaState extends State<Bienvenida> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

        // Construye un menu contextual o de hamburguesa
        drawer: Drawer(
          child: ListView(
            // espacio
            padding: EdgeInsets.all(0),
            // Agregamos varios widgets
            children: [
              UserAccountsDrawerHeader(
                decoration: BoxDecoration(color: Colors.deepPurple),
                accountName: Text("Jesús Verduzco"),
                accountEmail: Text("jesus_verduzco@ucol.mx"),
                currentAccountPicture: Image.asset("img/mifoto.jpg"),
              ),

              // Opciones del menu contextual
              ListTile(
                title: Text("Perfil"),
                leading: Icon(Icons.person),
                // Listener de los eventos
                onTap: () {
                  // Oculta el menu contextual retirando la pantalla del tope
                  Navigator.of(context).pop();
                  // Salta al formulario especificado
                  Navigator.pushNamed(context, '/perfil');
                },
              ),
              // Segunda opción
              ListTile(
                title: const Text("CV"),
                // Icono
                leading: const Icon(Icons.photo_album),
                // Listener
                onTap: () {
                  // Ocultamos el menu contextual
                  Navigator.of(context).pop();
                  // SAltamos a una clase cv
                  Navigator.pushNamed(context, "/cv");
                },
              ),
            ],
          ),
        ),
        backgroundColor: const Color.fromARGB(255, 215, 235, 245),
        appBar: AppBar(
          title: const Text("Bienvenida"),
        ),
        body: ListView(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              child: Text(
                //'Bienvenido:'  + widget.name,
                'Bienvenido:',
                // ignore: prefer_const_constructors
                style: TextStyle(
                  fontSize: 20,
                  fontFamily: "rbold",
                ),
              ),
            ),
            SizedBox(
              width: 80, // ancho deseado
              height: 40, // alto deseado // alto deseado
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue, // Color de fondo ámbar
                  elevation: 5, // button elevation
                  shape: RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.circular(10), // Esquinas cuadradas
                  ),
                ),
                label: const Text(
                  "Regresar",
                  style: TextStyle(color: Colors.white),
                ),
                onPressed: () {
                  // Regresamos a la página anterior
                  Navigator.of(context).pop();
                },
                icon: const Icon(Icons.add_to_home_screen),
              ),
            ),
          ],
        ));
  }
}
